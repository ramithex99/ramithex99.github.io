import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBdP6sVNnk_jT6ZaET7NBeH0OYISrlLLkw",
            authDomain: "drop-deli.firebaseapp.com",
            projectId: "drop-deli",
            storageBucket: "drop-deli.appspot.com",
            messagingSenderId: "662185219055",
            appId: "1:662185219055:web:8f02dbf77498604287dc1a",
            measurementId: "G-MDYJC3ZKZL"));
  } else {
    await Firebase.initializeApp();
  }
}
