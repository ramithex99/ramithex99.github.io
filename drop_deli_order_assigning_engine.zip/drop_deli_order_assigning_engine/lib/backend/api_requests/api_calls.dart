import 'dart:convert';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start flutterWave Group Code

class FlutterWaveGroup {
  static String getBaseUrl() => 'https://api.flutterwave.com';
  static Map<String, String> headers = {
    'Authorization': 'Bearer',
  };
  static FlutterwaveStandardCall flutterwaveStandardCall =
      FlutterwaveStandardCall();
  static FlutterwaveStandardcCall flutterwaveStandardcCall =
      FlutterwaveStandardcCall();
  static VerifyPaymentCall verifyPaymentCall = VerifyPaymentCall();
  static DirectchargeCall directchargeCall = DirectchargeCall();
}

class FlutterwaveStandardCall {
  Future<ApiCallResponse> call({
    String? txRef = '',
    double? amount,
    String? email = '',
    String? phoneNumber = '',
    String? name = '',
    String? consumerId = '',
    String? redirectUrl = '',
    String? currency = '',
  }) async {
    final baseUrl = FlutterWaveGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "tx_ref": "${txRef}",
  "amount": "${amount}",
  "currency": "${currency}",
  "redirect_url": "${redirectUrl}",
  "meta": {
    "consumer_id": "${consumerId}"
  },
  "customer": {
    "email": "${email}",
    "phonenumber": "${phoneNumber}",
    "name": "${name}"
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Flutterwave Standard',
      apiUrl: '${baseUrl}/v3/payments',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
  String? link(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.link''',
      ));
}

class FlutterwaveStandardcCall {
  Future<ApiCallResponse> call({
    String? txRef = '',
    double? amount,
    String? email = '',
    String? phoneNumber = '',
    String? name = '',
    String? consumerId = '',
    String? redirectUrl = '',
    String? currency = '',
  }) async {
    final baseUrl = FlutterWaveGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "tx_ref": "${txRef}",
  "amount": "${amount}",
  "currency": "${currency}",
  "redirect_url": "${redirectUrl}",
  "meta": {
    "consumer_id": "${consumerId}"
  },
  "customer": {
    "email": "${email}",
    "phonenumber": "${phoneNumber}",
    "name": "${name}"
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Flutterwave Standardc',
      apiUrl: '${baseUrl}/v3/payments',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
  String? link(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.link''',
      ));
}

class VerifyPaymentCall {
  Future<ApiCallResponse> call({
    String? txRef = '',
  }) async {
    final baseUrl = FlutterWaveGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'verifyPayment',
      apiUrl: '${baseUrl}/v3/transactions/verify_by_reference',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer',
      },
      params: {
        'tx_ref': txRef,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.status''',
      ));
  String? type(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.auth_model''',
      ));
  String? network(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.meta.MOMO_NETWORK''',
      ));
  double? charge(dynamic response) => castToType<double>(getJsonField(
        response,
        r'''$.data.app_fee''',
      ));
  String? number(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.customer.phone_number''',
      ));
  String? nocash(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.processor_response''',
      ));
}

class DirectchargeCall {
  Future<ApiCallResponse> call({
    String? ref = '',
    String? currency = 'GHS',
    String? phonenumber = '',
    String? network = '',
    String? email = '',
    String? name = '',
    String? amount = '',
  }) async {
    final baseUrl = FlutterWaveGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "tx_ref": "${ref}",
  "amount": "${amount}",
  "currency": "${currency}",
  "network": "${network}",
  "email": "${email}",
  "phone_number": "${phonenumber}",
  "fullname": "${name}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'directcharge',
      apiUrl: '${baseUrl}/v3/charges?type=mobile_money_ghana',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? link(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.meta.authorization.redirect''',
      ));
}

/// End flutterWave Group Code

/// Start paystack Payments Group Code

class PaystackPaymentsGroup {
  static String getBaseUrl({
    String? apiKey = '',
  }) =>
      'https://api.paystack.co';
  static Map<String, String> headers = {
    'Authorization': 'Bearer [apiKey]',
    'Content-Type': 'application/json',
  };
  static InitiateTransactionWthURLCall initiateTransactionWthURLCall =
      InitiateTransactionWthURLCall();
  static InitiateTransactionWithoutURLCall initiateTransactionWithoutURLCall =
      InitiateTransactionWithoutURLCall();
  static VerifyTransactionCall verifyTransactionCall = VerifyTransactionCall();
}

class InitiateTransactionWthURLCall {
  Future<ApiCallResponse> call({
    String? email = '',
    double? amount,
    String? ref = '',
    String? currency = '',
    String? callbackUrl = '',
    String? apiKey = '',
  }) async {
    final baseUrl = PaystackPaymentsGroup.getBaseUrl(
      apiKey: apiKey,
    );

    final ffApiRequestBody = '''
{
  "email": "${email}",
  "amount": "${amount}",
  "currency": "${currency}",
  "callback_url": "${callbackUrl}",
  "reference": "${ref}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'initiateTransactionWthURL',
      apiUrl: '${baseUrl}/transaction/initialize',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${apiKey}',
        'Content-Type': 'application/json',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? authorizationurl(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.authorization_url''',
      ));
  String? referenceID(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.reference''',
      ));
}

class InitiateTransactionWithoutURLCall {
  Future<ApiCallResponse> call({
    String? email = '',
    double? amount,
    String? ref = '',
    String? currency = '',
    String? apiKey = '',
  }) async {
    final baseUrl = PaystackPaymentsGroup.getBaseUrl(
      apiKey: apiKey,
    );

    final ffApiRequestBody = '''
{
  "email": "${email}",
  "amount": "${amount}",
  "currency": "${currency}",
  "reference": "${ref}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'initiateTransaction Without URL',
      apiUrl: '${baseUrl}/transaction/initialize',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${apiKey}',
        'Content-Type': 'application/json',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? authorizationurl(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.authorization_url''',
      ));
  String? referenceID(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.reference''',
      ));
}

class VerifyTransactionCall {
  Future<ApiCallResponse> call({
    String? referenceID = '',
    String? apiKey = '',
  }) async {
    final baseUrl = PaystackPaymentsGroup.getBaseUrl(
      apiKey: apiKey,
    );

    return ApiManager.instance.makeApiCall(
      callName: 'Verify Transaction',
      apiUrl: '${baseUrl}/transaction/verify/${referenceID}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${apiKey}',
        'Content-Type': 'application/json',
      },
      params: {
        'referenceID': referenceID,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  int? amount(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.data.amount''',
      ));
  String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.status''',
      ));
  String? source(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.authorization.mobile_money_number''',
      ));
  String? network(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.authorization.bank''',
      ));
  String? type(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.authorization.channel''',
      ));
  int? fee(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.data.fees_breakdown[:].amount''',
      ));
  String? nocash(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data.gateway_response''',
      ));
}

/// End paystack Payments Group Code

/// Start Solex App Group Code

class SolexAppGroup {
  static String getBaseUrl() =>
      'https://fastapi-production-09f6.up.railway.app/';
  static Map<String, String> headers = {};
  static SolexAuthCall solexAuthCall = SolexAuthCall();
}

class SolexAuthCall {
  Future<ApiCallResponse> call({
    String? email = '',
    String? password = '',
  }) async {
    final baseUrl = SolexAppGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'Solex Auth',
      apiUrl: '${baseUrl}register_user',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'email': email,
        'password': password,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End Solex App Group Code

/// Start Apisms Group Code

class ApismsGroup {
  static String getBaseUrl() => 'https://api.icsms.net/sendsms/';
  static Map<String, String> headers = {};
}

/// End Apisms Group Code

class GetUsdCodeCall {
  static Future<ApiCallResponse> call({
    String? country = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'getUsdCode',
      apiUrl: 'http://country.io/phone.json',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'country': country,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CountryNamesCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'countryNames',
      apiUrl: 'http://country.io/names.json',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CountriesCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'countries',
      apiUrl: 'http://18.218.86.142/country.php',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class NotificationCall {
  static Future<ApiCallResponse> call({
    String? pin = '',
    String? name = '',
    String? email = '',
  }) async {
    final ffApiRequestBody = '''
{
  "name": "Awesome Campaign",
  "subject": "SoLex Growth",
  "from": "n0-replyotp@solexgrowth.com",
  "reply_to": "no-replyotp@solexgrowth.com",
  "company": "Yournotify",
  "html": "<p>Hello ${name} This is your verification code ${pin}</p>",
  "text": "Hello ${name} This is your ${pin}",
  "status": "running",
  "lists": [
    "${email}"
  ],
  "channel": "email",
  "campaign_type": "promotional"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Notification',
      apiUrl: 'https://api.yournotify.com/campaigns/email',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class OtpSmsCall {
  static Future<ApiCallResponse> call({
    String? apikey = '',
    String? from = '',
    String? to = '',
    String? pinCode = '',
    String? userName = '',
  }) async {
    final ffApiRequestBody = '''
{
  "apikey": "${apikey}",
  "from": "${from}",
  "to": "${to}",
  "message": "Hello ${userName} this is your verification code ${pinCode}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'OTP SMS',
      apiUrl: 'https://api.icsms.net/sendsms/',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${apikey}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
