import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  bool hasCountry() => _country != null;

  // "user_currency" field.
  String? _userCurrency;
  String get userCurrency => _userCurrency ?? '';
  bool hasUserCurrency() => _userCurrency != null;

  // "lastname" field.
  String? _lastname;
  String get lastname => _lastname ?? '';
  bool hasLastname() => _lastname != null;

  // "online" field.
  bool? _online;
  bool get online => _online ?? false;
  bool hasOnline() => _online != null;

  // "isrider" field.
  bool? _isrider;
  bool get isrider => _isrider ?? false;
  bool hasIsrider() => _isrider != null;

  // "inActiveOrder" field.
  bool? _inActiveOrder;
  bool get inActiveOrder => _inActiveOrder ?? false;
  bool hasInActiveOrder() => _inActiveOrder != null;

  // "ReadyToWork" field.
  bool? _readyToWork;
  bool get readyToWork => _readyToWork ?? false;
  bool hasReadyToWork() => _readyToWork != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "assigning" field.
  bool? _assigning;
  bool get assigning => _assigning ?? false;
  bool hasAssigning() => _assigning != null;

  // "restaurantPayOutBalance" field.
  double? _restaurantPayOutBalance;
  double get restaurantPayOutBalance => _restaurantPayOutBalance ?? 0.0;
  bool hasRestaurantPayOutBalance() => _restaurantPayOutBalance != null;

  // "Balance" field.
  double? _balance;
  double get balance => _balance ?? 0.0;
  bool hasBalance() => _balance != null;

  // "onboarding" field.
  bool? _onboarding;
  bool get onboarding => _onboarding ?? false;
  bool hasOnboarding() => _onboarding != null;

  // "acceptingOrders" field.
  bool? _acceptingOrders;
  bool get acceptingOrders => _acceptingOrders ?? false;
  bool hasAcceptingOrders() => _acceptingOrders != null;

  // "restricted" field.
  bool? _restricted;
  bool get restricted => _restricted ?? false;
  bool hasRestricted() => _restricted != null;

  // "deliveryDiscountValue" field.
  double? _deliveryDiscountValue;
  double get deliveryDiscountValue => _deliveryDiscountValue ?? 0.0;
  bool hasDeliveryDiscountValue() => _deliveryDiscountValue != null;

  // "newRequest" field.
  bool? _newRequest;
  bool get newRequest => _newRequest ?? false;
  bool hasNewRequest() => _newRequest != null;

  // "Restaurantaddress" field.
  String? _restaurantaddress;
  String get restaurantaddress => _restaurantaddress ?? '';
  bool hasRestaurantaddress() => _restaurantaddress != null;

  // "OutStandingBalance" field.
  double? _outStandingBalance;
  double get outStandingBalance => _outStandingBalance ?? 0.0;
  bool hasOutStandingBalance() => _outStandingBalance != null;

  // "isARestaurant" field.
  bool? _isARestaurant;
  bool get isARestaurant => _isARestaurant ?? false;
  bool hasIsARestaurant() => _isARestaurant != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _country = snapshotData['country'] as String?;
    _userCurrency = snapshotData['user_currency'] as String?;
    _lastname = snapshotData['lastname'] as String?;
    _online = snapshotData['online'] as bool?;
    _isrider = snapshotData['isrider'] as bool?;
    _inActiveOrder = snapshotData['inActiveOrder'] as bool?;
    _readyToWork = snapshotData['ReadyToWork'] as bool?;
    _location = snapshotData['location'] as LatLng?;
    _assigning = snapshotData['assigning'] as bool?;
    _restaurantPayOutBalance =
        castToType<double>(snapshotData['restaurantPayOutBalance']);
    _balance = castToType<double>(snapshotData['Balance']);
    _onboarding = snapshotData['onboarding'] as bool?;
    _acceptingOrders = snapshotData['acceptingOrders'] as bool?;
    _restricted = snapshotData['restricted'] as bool?;
    _deliveryDiscountValue =
        castToType<double>(snapshotData['deliveryDiscountValue']);
    _newRequest = snapshotData['newRequest'] as bool?;
    _restaurantaddress = snapshotData['Restaurantaddress'] as String?;
    _outStandingBalance =
        castToType<double>(snapshotData['OutStandingBalance']);
    _isARestaurant = snapshotData['isARestaurant'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? country,
  String? userCurrency,
  String? lastname,
  bool? online,
  bool? isrider,
  bool? inActiveOrder,
  bool? readyToWork,
  LatLng? location,
  bool? assigning,
  double? restaurantPayOutBalance,
  double? balance,
  bool? onboarding,
  bool? acceptingOrders,
  bool? restricted,
  double? deliveryDiscountValue,
  bool? newRequest,
  String? restaurantaddress,
  double? outStandingBalance,
  bool? isARestaurant,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'country': country,
      'user_currency': userCurrency,
      'lastname': lastname,
      'online': online,
      'isrider': isrider,
      'inActiveOrder': inActiveOrder,
      'ReadyToWork': readyToWork,
      'location': location,
      'assigning': assigning,
      'restaurantPayOutBalance': restaurantPayOutBalance,
      'Balance': balance,
      'onboarding': onboarding,
      'acceptingOrders': acceptingOrders,
      'restricted': restricted,
      'deliveryDiscountValue': deliveryDiscountValue,
      'newRequest': newRequest,
      'Restaurantaddress': restaurantaddress,
      'OutStandingBalance': outStandingBalance,
      'isARestaurant': isARestaurant,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.country == e2?.country &&
        e1?.userCurrency == e2?.userCurrency &&
        e1?.lastname == e2?.lastname &&
        e1?.online == e2?.online &&
        e1?.isrider == e2?.isrider &&
        e1?.inActiveOrder == e2?.inActiveOrder &&
        e1?.readyToWork == e2?.readyToWork &&
        e1?.location == e2?.location &&
        e1?.assigning == e2?.assigning &&
        e1?.restaurantPayOutBalance == e2?.restaurantPayOutBalance &&
        e1?.balance == e2?.balance &&
        e1?.onboarding == e2?.onboarding &&
        e1?.acceptingOrders == e2?.acceptingOrders &&
        e1?.restricted == e2?.restricted &&
        e1?.deliveryDiscountValue == e2?.deliveryDiscountValue &&
        e1?.newRequest == e2?.newRequest &&
        e1?.restaurantaddress == e2?.restaurantaddress &&
        e1?.outStandingBalance == e2?.outStandingBalance &&
        e1?.isARestaurant == e2?.isARestaurant;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.country,
        e?.userCurrency,
        e?.lastname,
        e?.online,
        e?.isrider,
        e?.inActiveOrder,
        e?.readyToWork,
        e?.location,
        e?.assigning,
        e?.restaurantPayOutBalance,
        e?.balance,
        e?.onboarding,
        e?.acceptingOrders,
        e?.restricted,
        e?.deliveryDiscountValue,
        e?.newRequest,
        e?.restaurantaddress,
        e?.outStandingBalance,
        e?.isARestaurant
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
