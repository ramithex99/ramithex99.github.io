import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DayMonitorRecord extends FirestoreRecord {
  DayMonitorRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "riderRef" field.
  DocumentReference? _riderRef;
  DocumentReference? get riderRef => _riderRef;
  bool hasRiderRef() => _riderRef != null;

  void _initializeFields() {
    _date = snapshotData['date'] as DateTime?;
    _riderRef = snapshotData['riderRef'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('dayMonitor');

  static Stream<DayMonitorRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DayMonitorRecord.fromSnapshot(s));

  static Future<DayMonitorRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DayMonitorRecord.fromSnapshot(s));

  static DayMonitorRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DayMonitorRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DayMonitorRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DayMonitorRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DayMonitorRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DayMonitorRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDayMonitorRecordData({
  DateTime? date,
  DocumentReference? riderRef,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'date': date,
      'riderRef': riderRef,
    }.withoutNulls,
  );

  return firestoreData;
}

class DayMonitorRecordDocumentEquality implements Equality<DayMonitorRecord> {
  const DayMonitorRecordDocumentEquality();

  @override
  bool equals(DayMonitorRecord? e1, DayMonitorRecord? e2) {
    return e1?.date == e2?.date && e1?.riderRef == e2?.riderRef;
  }

  @override
  int hash(DayMonitorRecord? e) =>
      const ListEquality().hash([e?.date, e?.riderRef]);

  @override
  bool isValidKey(Object? o) => o is DayMonitorRecord;
}
