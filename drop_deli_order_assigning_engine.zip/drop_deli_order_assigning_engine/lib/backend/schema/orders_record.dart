import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrdersRecord extends FirestoreRecord {
  OrdersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "vendor_name" field.
  String? _vendorName;
  String get vendorName => _vendorName ?? '';
  bool hasVendorName() => _vendorName != null;

  // "user_ref" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "orderPlaced" field.
  bool? _orderPlaced;
  bool get orderPlaced => _orderPlaced ?? false;
  bool hasOrderPlaced() => _orderPlaced != null;

  // "creaated_at" field.
  DateTime? _creaatedAt;
  DateTime? get creaatedAt => _creaatedAt;
  bool hasCreaatedAt() => _creaatedAt != null;

  // "ratings" field.
  int? _ratings;
  int get ratings => _ratings ?? 0;
  bool hasRatings() => _ratings != null;

  // "rated" field.
  bool? _rated;
  bool get rated => _rated ?? false;
  bool hasRated() => _rated != null;

  // "preparing" field.
  bool? _preparing;
  bool get preparing => _preparing ?? false;
  bool hasPreparing() => _preparing != null;

  // "delivery" field.
  bool? _delivery;
  bool get delivery => _delivery ?? false;
  bool hasDelivery() => _delivery != null;

  // "delivered" field.
  bool? _delivered;
  bool get delivered => _delivered ?? false;
  bool hasDelivered() => _delivered != null;

  // "ready" field.
  bool? _ready;
  bool get ready => _ready ?? false;
  bool hasReady() => _ready != null;

  // "riderAssinged" field.
  bool? _riderAssinged;
  bool get riderAssinged => _riderAssinged ?? false;
  bool hasRiderAssinged() => _riderAssinged != null;

  // "preparingTime" field.
  DateTime? _preparingTime;
  DateTime? get preparingTime => _preparingTime;
  bool hasPreparingTime() => _preparingTime != null;

  // "ReadyTime" field.
  DateTime? _readyTime;
  DateTime? get readyTime => _readyTime;
  bool hasReadyTime() => _readyTime != null;

  // "pickedup" field.
  bool? _pickedup;
  bool get pickedup => _pickedup ?? false;
  bool hasPickedup() => _pickedup != null;

  // "riderAssingedTime" field.
  DateTime? _riderAssingedTime;
  DateTime? get riderAssingedTime => _riderAssingedTime;
  bool hasRiderAssingedTime() => _riderAssingedTime != null;

  // "DeliveredTime" field.
  DateTime? _deliveredTime;
  DateTime? get deliveredTime => _deliveredTime;
  bool hasDeliveredTime() => _deliveredTime != null;

  // "arriedAtrestaurant" field.
  bool? _arriedAtrestaurant;
  bool get arriedAtrestaurant => _arriedAtrestaurant ?? false;
  bool hasArriedAtrestaurant() => _arriedAtrestaurant != null;

  // "arrivedAtcustumerlocation" field.
  bool? _arrivedAtcustumerlocation;
  bool get arrivedAtcustumerlocation => _arrivedAtcustumerlocation ?? false;
  bool hasArrivedAtcustumerlocation() => _arrivedAtcustumerlocation != null;

  // "review" field.
  String? _review;
  String get review => _review ?? '';
  bool hasReview() => _review != null;

  // "comment" field.
  List<String>? _comment;
  List<String> get comment => _comment ?? const [];
  bool hasComment() => _comment != null;

  // "dislikecomment" field.
  List<String>? _dislikecomment;
  List<String> get dislikecomment => _dislikecomment ?? const [];
  bool hasDislikecomment() => _dislikecomment != null;

  // "ordrID" field.
  String? _ordrID;
  String get ordrID => _ordrID ?? '';
  bool hasOrdrID() => _ordrID != null;

  // "deliveryAddress" field.
  String? _deliveryAddress;
  String get deliveryAddress => _deliveryAddress ?? '';
  bool hasDeliveryAddress() => _deliveryAddress != null;

  // "DeliveryLatlng" field.
  LatLng? _deliveryLatlng;
  LatLng? get deliveryLatlng => _deliveryLatlng;
  bool hasDeliveryLatlng() => _deliveryLatlng != null;

  // "MessageToRider" field.
  String? _messageToRider;
  String get messageToRider => _messageToRider ?? '';
  bool hasMessageToRider() => _messageToRider != null;

  // "TimeToBeReady" field.
  double? _timeToBeReady;
  double get timeToBeReady => _timeToBeReady ?? 0.0;
  bool hasTimeToBeReady() => _timeToBeReady != null;

  // "deliveryRider" field.
  DocumentReference? _deliveryRider;
  DocumentReference? get deliveryRider => _deliveryRider;
  bool hasDeliveryRider() => _deliveryRider != null;

  // "isasinging" field.
  bool? _isasinging;
  bool get isasinging => _isasinging ?? false;
  bool hasIsasinging() => _isasinging != null;

  // "AcceptedOn" field.
  DateTime? _acceptedOn;
  DateTime? get acceptedOn => _acceptedOn;
  bool hasAcceptedOn() => _acceptedOn != null;

  // "assingingon" field.
  DateTime? _assingingon;
  DateTime? get assingingon => _assingingon;
  bool hasAssingingon() => _assingingon != null;

  // "RestaurantPin" field.
  String? _restaurantPin;
  String get restaurantPin => _restaurantPin ?? '';
  bool hasRestaurantPin() => _restaurantPin != null;

  // "kitchenNote" field.
  String? _kitchenNote;
  String get kitchenNote => _kitchenNote ?? '';
  bool hasKitchenNote() => _kitchenNote != null;

  // "date" field.
  DocumentReference? _date;
  DocumentReference? get date => _date;
  bool hasDate() => _date != null;

  // "riderDay" field.
  DocumentReference? _riderDay;
  DocumentReference? get riderDay => _riderDay;
  bool hasRiderDay() => _riderDay != null;

  // "restaurantRef" field.
  DocumentReference? _restaurantRef;
  DocumentReference? get restaurantRef => _restaurantRef;
  bool hasRestaurantRef() => _restaurantRef != null;

  // "Paid" field.
  bool? _paid;
  bool get paid => _paid ?? false;
  bool hasPaid() => _paid != null;

  // "accepted" field.
  bool? _accepted;
  bool get accepted => _accepted ?? false;
  bool hasAccepted() => _accepted != null;

  // "vendorPrice" field.
  double? _vendorPrice;
  double get vendorPrice => _vendorPrice ?? 0.0;
  bool hasVendorPrice() => _vendorPrice != null;

  // "Dismiss" field.
  bool? _dismiss;
  bool get dismiss => _dismiss ?? false;
  bool hasDismiss() => _dismiss != null;

  // "failedreason" field.
  String? _failedreason;
  String get failedreason => _failedreason ?? '';
  bool hasFailedreason() => _failedreason != null;

  // "Username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "userPhone" field.
  String? _userPhone;
  String get userPhone => _userPhone ?? '';
  bool hasUserPhone() => _userPhone != null;

  // "Ridername" field.
  String? _ridername;
  String get ridername => _ridername ?? '';
  bool hasRidername() => _ridername != null;

  // "Riderphonenumber" field.
  String? _riderphonenumber;
  String get riderphonenumber => _riderphonenumber ?? '';
  bool hasRiderphonenumber() => _riderphonenumber != null;

  // "Riderimage" field.
  String? _riderimage;
  String get riderimage => _riderimage ?? '';
  bool hasRiderimage() => _riderimage != null;

  // "pickingUp" field.
  bool? _pickingUp;
  bool get pickingUp => _pickingUp ?? false;
  bool hasPickingUp() => _pickingUp != null;

  // "userOntheway" field.
  bool? _userOntheway;
  bool get userOntheway => _userOntheway ?? false;
  bool hasUserOntheway() => _userOntheway != null;

  // "restaurantLocation" field.
  LatLng? _restaurantLocation;
  LatLng? get restaurantLocation => _restaurantLocation;
  bool hasRestaurantLocation() => _restaurantLocation != null;

  // "amount" field.
  double? _amount;
  double get amount => _amount ?? 0.0;
  bool hasAmount() => _amount != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  bool hasCountry() => _country != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _status = snapshotData['status'] as String?;
    _vendorName = snapshotData['vendor_name'] as String?;
    _userRef = snapshotData['user_ref'] as DocumentReference?;
    _orderPlaced = snapshotData['orderPlaced'] as bool?;
    _creaatedAt = snapshotData['creaated_at'] as DateTime?;
    _ratings = castToType<int>(snapshotData['ratings']);
    _rated = snapshotData['rated'] as bool?;
    _preparing = snapshotData['preparing'] as bool?;
    _delivery = snapshotData['delivery'] as bool?;
    _delivered = snapshotData['delivered'] as bool?;
    _ready = snapshotData['ready'] as bool?;
    _riderAssinged = snapshotData['riderAssinged'] as bool?;
    _preparingTime = snapshotData['preparingTime'] as DateTime?;
    _readyTime = snapshotData['ReadyTime'] as DateTime?;
    _pickedup = snapshotData['pickedup'] as bool?;
    _riderAssingedTime = snapshotData['riderAssingedTime'] as DateTime?;
    _deliveredTime = snapshotData['DeliveredTime'] as DateTime?;
    _arriedAtrestaurant = snapshotData['arriedAtrestaurant'] as bool?;
    _arrivedAtcustumerlocation =
        snapshotData['arrivedAtcustumerlocation'] as bool?;
    _review = snapshotData['review'] as String?;
    _comment = getDataList(snapshotData['comment']);
    _dislikecomment = getDataList(snapshotData['dislikecomment']);
    _ordrID = snapshotData['ordrID'] as String?;
    _deliveryAddress = snapshotData['deliveryAddress'] as String?;
    _deliveryLatlng = snapshotData['DeliveryLatlng'] as LatLng?;
    _messageToRider = snapshotData['MessageToRider'] as String?;
    _timeToBeReady = castToType<double>(snapshotData['TimeToBeReady']);
    _deliveryRider = snapshotData['deliveryRider'] as DocumentReference?;
    _isasinging = snapshotData['isasinging'] as bool?;
    _acceptedOn = snapshotData['AcceptedOn'] as DateTime?;
    _assingingon = snapshotData['assingingon'] as DateTime?;
    _restaurantPin = snapshotData['RestaurantPin'] as String?;
    _kitchenNote = snapshotData['kitchenNote'] as String?;
    _date = snapshotData['date'] as DocumentReference?;
    _riderDay = snapshotData['riderDay'] as DocumentReference?;
    _restaurantRef = snapshotData['restaurantRef'] as DocumentReference?;
    _paid = snapshotData['Paid'] as bool?;
    _accepted = snapshotData['accepted'] as bool?;
    _vendorPrice = castToType<double>(snapshotData['vendorPrice']);
    _dismiss = snapshotData['Dismiss'] as bool?;
    _failedreason = snapshotData['failedreason'] as String?;
    _username = snapshotData['Username'] as String?;
    _userPhone = snapshotData['userPhone'] as String?;
    _ridername = snapshotData['Ridername'] as String?;
    _riderphonenumber = snapshotData['Riderphonenumber'] as String?;
    _riderimage = snapshotData['Riderimage'] as String?;
    _pickingUp = snapshotData['pickingUp'] as bool?;
    _userOntheway = snapshotData['userOntheway'] as bool?;
    _restaurantLocation = snapshotData['restaurantLocation'] as LatLng?;
    _amount = castToType<double>(snapshotData['amount']);
    _country = snapshotData['country'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Orders')
          : FirebaseFirestore.instance.collectionGroup('Orders');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Orders').doc(id);

  static Stream<OrdersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrdersRecord.fromSnapshot(s));

  static Future<OrdersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrdersRecord.fromSnapshot(s));

  static OrdersRecord fromSnapshot(DocumentSnapshot snapshot) => OrdersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrdersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrdersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrdersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrdersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrdersRecordData({
  String? status,
  String? vendorName,
  DocumentReference? userRef,
  bool? orderPlaced,
  DateTime? creaatedAt,
  int? ratings,
  bool? rated,
  bool? preparing,
  bool? delivery,
  bool? delivered,
  bool? ready,
  bool? riderAssinged,
  DateTime? preparingTime,
  DateTime? readyTime,
  bool? pickedup,
  DateTime? riderAssingedTime,
  DateTime? deliveredTime,
  bool? arriedAtrestaurant,
  bool? arrivedAtcustumerlocation,
  String? review,
  String? ordrID,
  String? deliveryAddress,
  LatLng? deliveryLatlng,
  String? messageToRider,
  double? timeToBeReady,
  DocumentReference? deliveryRider,
  bool? isasinging,
  DateTime? acceptedOn,
  DateTime? assingingon,
  String? restaurantPin,
  String? kitchenNote,
  DocumentReference? date,
  DocumentReference? riderDay,
  DocumentReference? restaurantRef,
  bool? paid,
  bool? accepted,
  double? vendorPrice,
  bool? dismiss,
  String? failedreason,
  String? username,
  String? userPhone,
  String? ridername,
  String? riderphonenumber,
  String? riderimage,
  bool? pickingUp,
  bool? userOntheway,
  LatLng? restaurantLocation,
  double? amount,
  String? country,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'status': status,
      'vendor_name': vendorName,
      'user_ref': userRef,
      'orderPlaced': orderPlaced,
      'creaated_at': creaatedAt,
      'ratings': ratings,
      'rated': rated,
      'preparing': preparing,
      'delivery': delivery,
      'delivered': delivered,
      'ready': ready,
      'riderAssinged': riderAssinged,
      'preparingTime': preparingTime,
      'ReadyTime': readyTime,
      'pickedup': pickedup,
      'riderAssingedTime': riderAssingedTime,
      'DeliveredTime': deliveredTime,
      'arriedAtrestaurant': arriedAtrestaurant,
      'arrivedAtcustumerlocation': arrivedAtcustumerlocation,
      'review': review,
      'ordrID': ordrID,
      'deliveryAddress': deliveryAddress,
      'DeliveryLatlng': deliveryLatlng,
      'MessageToRider': messageToRider,
      'TimeToBeReady': timeToBeReady,
      'deliveryRider': deliveryRider,
      'isasinging': isasinging,
      'AcceptedOn': acceptedOn,
      'assingingon': assingingon,
      'RestaurantPin': restaurantPin,
      'kitchenNote': kitchenNote,
      'date': date,
      'riderDay': riderDay,
      'restaurantRef': restaurantRef,
      'Paid': paid,
      'accepted': accepted,
      'vendorPrice': vendorPrice,
      'Dismiss': dismiss,
      'failedreason': failedreason,
      'Username': username,
      'userPhone': userPhone,
      'Ridername': ridername,
      'Riderphonenumber': riderphonenumber,
      'Riderimage': riderimage,
      'pickingUp': pickingUp,
      'userOntheway': userOntheway,
      'restaurantLocation': restaurantLocation,
      'amount': amount,
      'country': country,
    }.withoutNulls,
  );

  return firestoreData;
}

class OrdersRecordDocumentEquality implements Equality<OrdersRecord> {
  const OrdersRecordDocumentEquality();

  @override
  bool equals(OrdersRecord? e1, OrdersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.status == e2?.status &&
        e1?.vendorName == e2?.vendorName &&
        e1?.userRef == e2?.userRef &&
        e1?.orderPlaced == e2?.orderPlaced &&
        e1?.creaatedAt == e2?.creaatedAt &&
        e1?.ratings == e2?.ratings &&
        e1?.rated == e2?.rated &&
        e1?.preparing == e2?.preparing &&
        e1?.delivery == e2?.delivery &&
        e1?.delivered == e2?.delivered &&
        e1?.ready == e2?.ready &&
        e1?.riderAssinged == e2?.riderAssinged &&
        e1?.preparingTime == e2?.preparingTime &&
        e1?.readyTime == e2?.readyTime &&
        e1?.pickedup == e2?.pickedup &&
        e1?.riderAssingedTime == e2?.riderAssingedTime &&
        e1?.deliveredTime == e2?.deliveredTime &&
        e1?.arriedAtrestaurant == e2?.arriedAtrestaurant &&
        e1?.arrivedAtcustumerlocation == e2?.arrivedAtcustumerlocation &&
        e1?.review == e2?.review &&
        listEquality.equals(e1?.comment, e2?.comment) &&
        listEquality.equals(e1?.dislikecomment, e2?.dislikecomment) &&
        e1?.ordrID == e2?.ordrID &&
        e1?.deliveryAddress == e2?.deliveryAddress &&
        e1?.deliveryLatlng == e2?.deliveryLatlng &&
        e1?.messageToRider == e2?.messageToRider &&
        e1?.timeToBeReady == e2?.timeToBeReady &&
        e1?.deliveryRider == e2?.deliveryRider &&
        e1?.isasinging == e2?.isasinging &&
        e1?.acceptedOn == e2?.acceptedOn &&
        e1?.assingingon == e2?.assingingon &&
        e1?.restaurantPin == e2?.restaurantPin &&
        e1?.kitchenNote == e2?.kitchenNote &&
        e1?.date == e2?.date &&
        e1?.riderDay == e2?.riderDay &&
        e1?.restaurantRef == e2?.restaurantRef &&
        e1?.paid == e2?.paid &&
        e1?.accepted == e2?.accepted &&
        e1?.vendorPrice == e2?.vendorPrice &&
        e1?.dismiss == e2?.dismiss &&
        e1?.failedreason == e2?.failedreason &&
        e1?.username == e2?.username &&
        e1?.userPhone == e2?.userPhone &&
        e1?.ridername == e2?.ridername &&
        e1?.riderphonenumber == e2?.riderphonenumber &&
        e1?.riderimage == e2?.riderimage &&
        e1?.pickingUp == e2?.pickingUp &&
        e1?.userOntheway == e2?.userOntheway &&
        e1?.restaurantLocation == e2?.restaurantLocation &&
        e1?.amount == e2?.amount &&
        e1?.country == e2?.country;
  }

  @override
  int hash(OrdersRecord? e) => const ListEquality().hash([
        e?.status,
        e?.vendorName,
        e?.userRef,
        e?.orderPlaced,
        e?.creaatedAt,
        e?.ratings,
        e?.rated,
        e?.preparing,
        e?.delivery,
        e?.delivered,
        e?.ready,
        e?.riderAssinged,
        e?.preparingTime,
        e?.readyTime,
        e?.pickedup,
        e?.riderAssingedTime,
        e?.deliveredTime,
        e?.arriedAtrestaurant,
        e?.arrivedAtcustumerlocation,
        e?.review,
        e?.comment,
        e?.dislikecomment,
        e?.ordrID,
        e?.deliveryAddress,
        e?.deliveryLatlng,
        e?.messageToRider,
        e?.timeToBeReady,
        e?.deliveryRider,
        e?.isasinging,
        e?.acceptedOn,
        e?.assingingon,
        e?.restaurantPin,
        e?.kitchenNote,
        e?.date,
        e?.riderDay,
        e?.restaurantRef,
        e?.paid,
        e?.accepted,
        e?.vendorPrice,
        e?.dismiss,
        e?.failedreason,
        e?.username,
        e?.userPhone,
        e?.ridername,
        e?.riderphonenumber,
        e?.riderimage,
        e?.pickingUp,
        e?.userOntheway,
        e?.restaurantLocation,
        e?.amount,
        e?.country
      ]);

  @override
  bool isValidKey(Object? o) => o is OrdersRecord;
}
