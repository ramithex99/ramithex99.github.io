import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'af', 'ar'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? afText = '',
    String? arText = '',
  }) =>
      [enText, afText, arText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    '4wmv7az3': {
      'en': 'Button',
      'af': '',
      'ar': '',
    },
    'qjbb1qe2': {
      'en': ' Orders',
      'af': '',
      'ar': '',
    },
  },
  // orders
  {
    'vv1cv7mi': {
      'en': 'Home',
      'af': '',
      'ar': '',
    },
  },
  // Miscellaneous
  {
    '52ez5j7m': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'u0tnbbcv': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '1vm80g0f': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '0dm6okih': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '2z5pkp0u': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '0bjhapul': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'izf88dvs': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'ary3mbo0': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '06vtxwdf': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '26tpgqui': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'xlkwf5em': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'mrx4fdol': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'qhsd3hxr': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'trx545pw': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'timmqdid': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'gtutavjs': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'c95w414y': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'ehzlyc2p': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'mziu1q9j': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'hb3wj63y': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '019jwrns': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'a21v4pc8': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'to06z3ad': {
      'en': '',
      'af': '',
      'ar': '',
    },
    '5s9a0791': {
      'en': '',
      'af': '',
      'ar': '',
    },
    'z5j9h1l9': {
      'en': '',
      'af': '',
      'ar': '',
    },
  },
].reduce((a, b) => a..addAll(b));
