import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

bool timerr(DateTime time) {
  // Get the current system time
  DateTime currentTime = DateTime.now();

  // Calculate the time difference in seconds
  Duration difference = currentTime.difference(time);

  // Print the time difference for debugging
  print('Current Time: $currentTime');
  print('Initial Time: $time');
  print('Difference in seconds: ${difference.inSeconds}');

  // Return true if 20 seconds or more have passed
  return difference.inSeconds >= 20;
}

DateTime? currentDate(DateTime? time) {
  // get date out of time just the date
  if (time == null) {
    return null;
  }
  return DateTime(time.year, time.month, time.day);
}

bool? minutes(
  DateTime createdtime,
  int time,
) {
  // if createdtime passed time in minutes return true else false
  final now = DateTime.now();
  final difference = now.difference(createdtime);
  final differenceInMinutes = difference.inMinutes;
  return differenceInMinutes >= time;
}

List<UsersRecord> nearByrider(
  List<UsersRecord> places,
  LatLng userGeo,
  double maxDistance,
) {
  List<UsersRecord> placesList = [];
  List<double> listKm = [];
  double lat1 = userGeo.latitude;
  double lon1 = userGeo.longitude;
  // This iterates through the single documents "places" in the List
  for (UsersRecord place in places) {
    double lat2 = place.location!.latitude;
    double lon2 = place.location!.longitude;
    // This is doing math for distance calculations on the surface of a spheroid
    var c = math.cos;
    var p = 0.017453292519943295;
    var a = 0.5 -
        c((lat2 - lat1) * p) / 2 +
        c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p)) / 2;
    // This is getting us the distance
    var d = (12742 * math.asin(math.sqrt(a)));
    String inString = d.toStringAsFixed(2); // '2.35'
    double inDouble = double.parse(inString);
    listKm.add(inDouble);
    // Sort the documents that will be returned by distance
    listKm.sort();
    int listKmIndex = listKm.indexWhere((dist) => dist == inDouble);
    // Check if the document we are currently processing is no farther away from userGeo than we defined as max.
    if (inDouble <= maxDistance) {
      // If its within our radius, add it to the list of places documents that will be returned
      placesList.insert(listKmIndex, place);
    }
  }
  return placesList;
}
