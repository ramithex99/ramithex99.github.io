import '/backend/backend.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';

Future assignOrder(BuildContext context) async {}

Future unassgn6(BuildContext context) async {
  List<OrdersRecord>? tyui;

  tyui = await queryOrdersRecordOnce(
    queryBuilder: (ordersRecord) => ordersRecord
        .where(
          'isasinging',
          isEqualTo: true,
        )
        .where(
          'riderAssinged',
          isNotEqualTo: true,
        ),
  );

  await tyui
      .where((e) => functions.timerr(e.assingingon!))
      .toList()
      .firstOrNull!
      .reference
      .update({
    ...createOrdersRecordData(
      isasinging: false,
      riderAssinged: false,
    ),
    ...mapToFirestore(
      {
        'assingingon': FieldValue.delete(),
        'deliveryRider': FieldValue.delete(),
      },
    ),
  });

  await tyui
      .where((e) => functions.timerr(e.assingingon!))
      .toList()
      .firstOrNull!
      .deliveryRider!
      .update(createUsersRecordData(
        online: false,
        readyToWork: false,
        assigning: false,
      ));
}
