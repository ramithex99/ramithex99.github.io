import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'home_page_widget.dart' show HomePageWidget;
import 'package:flutter/material.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  bool tap = false;

  bool finish = false;

  List<String> list = ['Hello World', 'Hello World'];
  void addToList(String item) => list.add(item);
  void removeFromList(String item) => list.remove(item);
  void removeAtIndexFromList(int index) => list.removeAt(index);
  void insertAtIndexInList(int index, String item) => list.insert(index, item);
  void updateListAtIndex(int index, Function(String) updateFn) =>
      list[index] = updateFn(list[index]);

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  OrdersRecord? unsignOrder;
  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  List<UsersRecord>? riderFound;
  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  DayMonitorRecord? day;
  // Stores action output result for [Backend Call - Create Document] action in HomePage widget.
  DayMonitorRecord? createdDay;
  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  OrdersRecord? orderNot;
  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  UsersRecord? user;
  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  List<OrdersRecord>? orderListFound22;
  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  List<UsersRecord>? riderFound2;
  // Stores action output result for [Firestore Query - Query a collection] action in HomePage widget.
  DayMonitorRecord? day2;
  // Stores action output result for [Backend Call - Create Document] action in HomePage widget.
  DayMonitorRecord? createdDay2;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  OrdersRecord? unsignOrdery;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
