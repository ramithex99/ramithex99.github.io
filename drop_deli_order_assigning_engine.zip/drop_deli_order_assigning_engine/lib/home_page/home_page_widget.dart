import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'home_page_model.dart';
export 'home_page_model.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({super.key});

  static String routeName = 'HomePage';
  static String routePath = 'homePage';

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  late HomePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomePageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.wait([
        Future(() async {
          while (!_model.finish) {
            _model.unsignOrder = await queryOrdersRecordOnce(
              queryBuilder: (ordersRecord) => ordersRecord
                  .where(
                    'riderAssinged',
                    isEqualTo: false,
                  )
                  .where(
                    'status',
                    isEqualTo: 'In progress',
                  )
                  .where(
                    'pickingUp',
                    isEqualTo: false,
                  )
                  .where(
                    'delivered',
                    isEqualTo: false,
                  )
                  .where(
                    'isasinging',
                    isEqualTo: false,
                  ),
              singleRecord: true,
            ).then((s) => s.firstOrNull);
            if (_model.unsignOrder != null) {
              _model.riderFound = await queryUsersRecordOnce(
                queryBuilder: (usersRecord) => usersRecord
                    .where(
                      'online',
                      isEqualTo: true,
                    )
                    .where(
                      'isrider',
                      isEqualTo: true,
                    )
                    .where(
                      'inActiveOrder',
                      isEqualTo: false,
                    )
                    .where(
                      'ReadyToWork',
                      isEqualTo: true,
                    )
                    .where(
                      'assigning',
                      isEqualTo: false,
                    )
                    .where(
                      'country',
                      isEqualTo: _model.unsignOrder?.country,
                    )
                    .orderBy('location', descending: true),
              );
              if (functions
                  .nearByrider(
                      _model.riderFound!
                          .where((e) =>
                              (e.online == true) &&
                              (e.inActiveOrder == false) &&
                              (e.assigning == false) &&
                              (e.readyToWork == true) &&
                              (e.isrider == true) &&
                              (e.outStandingBalance <= 198.0))
                          .toList()
                          .toList(),
                      _model.unsignOrder!.restaurantLocation!,
                      10.0)
                  .isNotEmpty) {
                _model.day = await queryDayMonitorRecordOnce(
                  queryBuilder: (dayMonitorRecord) => dayMonitorRecord
                      .where(
                        'date',
                        isEqualTo: functions.currentDate(getCurrentTimestamp),
                      )
                      .where(
                        'riderRef',
                        isEqualTo: functions
                            .nearByrider(
                                _model.riderFound!
                                    .where((e) =>
                                        (e.online == true) &&
                                        (e.inActiveOrder == false) &&
                                        (e.assigning == false) &&
                                        (e.readyToWork == true) &&
                                        (e.isrider == true) &&
                                        (e.outStandingBalance <= 198.0))
                                    .toList()
                                    .toList(),
                                _model.unsignOrder!.restaurantLocation!,
                                10.0)
                            .firstOrNull
                            ?.reference,
                      ),
                  singleRecord: true,
                ).then((s) => s.firstOrNull);
                if (_model.day != null) {
                  await _model.unsignOrder!.reference
                      .update(createOrdersRecordData(
                    deliveryRider: functions
                        .nearByrider(
                            _model.riderFound!
                                .where((e) =>
                                    (e.online == true) &&
                                    (e.inActiveOrder == false) &&
                                    (e.assigning == false) &&
                                    (e.readyToWork == true) &&
                                    (e.isrider == true) &&
                                    (e.outStandingBalance <= 198.0))
                                .toList()
                                .toList(),
                            _model.unsignOrder!.restaurantLocation!,
                            10.0)
                        .firstOrNull
                        ?.reference,
                    isasinging: true,
                    assingingon: getCurrentTimestamp,
                    riderDay: _model.day?.reference,
                  ));

                  await functions
                      .nearByrider(
                          _model.riderFound!
                              .where((e) =>
                                  (e.online == true) &&
                                  (e.inActiveOrder == false) &&
                                  (e.assigning == false) &&
                                  (e.readyToWork == true) &&
                                  (e.isrider == true) &&
                                  (e.outStandingBalance <= 198.0))
                              .toList()
                              .toList(),
                          _model.unsignOrder!.restaurantLocation!,
                          10.0)
                      .firstOrNull!
                      .reference
                      .update(createUsersRecordData(
                        assigning: true,
                      ));
                } else {
                  var dayMonitorRecordReference1 =
                      DayMonitorRecord.collection.doc();
                  await dayMonitorRecordReference1
                      .set(createDayMonitorRecordData(
                    date: functions.currentDate(getCurrentTimestamp),
                    riderRef: functions
                        .nearByrider(
                            _model.riderFound!
                                .where((e) =>
                                    (e.online == true) &&
                                    (e.inActiveOrder == false) &&
                                    (e.assigning == false) &&
                                    (e.readyToWork == true) &&
                                    (e.isrider == true) &&
                                    (e.outStandingBalance <= 198.0))
                                .toList()
                                .toList(),
                            _model.unsignOrder!.restaurantLocation!,
                            10.0)
                        .firstOrNull
                        ?.reference,
                  ));
                  _model.createdDay = DayMonitorRecord.getDocumentFromData(
                      createDayMonitorRecordData(
                        date: functions.currentDate(getCurrentTimestamp),
                        riderRef: functions
                            .nearByrider(
                                _model.riderFound!
                                    .where((e) =>
                                        (e.online == true) &&
                                        (e.inActiveOrder == false) &&
                                        (e.assigning == false) &&
                                        (e.readyToWork == true) &&
                                        (e.isrider == true) &&
                                        (e.outStandingBalance <= 198.0))
                                    .toList()
                                    .toList(),
                                _model.unsignOrder!.restaurantLocation!,
                                10.0)
                            .firstOrNull
                            ?.reference,
                      ),
                      dayMonitorRecordReference1);

                  await _model.unsignOrder!.reference
                      .update(createOrdersRecordData(
                    deliveryRider: functions
                        .nearByrider(
                            _model.riderFound!
                                .where((e) =>
                                    (e.online == true) &&
                                    (e.inActiveOrder == false) &&
                                    (e.assigning == false) &&
                                    (e.readyToWork == true) &&
                                    (e.isrider == true) &&
                                    (e.outStandingBalance <= 198.0))
                                .toList()
                                .toList(),
                            _model.unsignOrder!.restaurantLocation!,
                            10.0)
                        .firstOrNull
                        ?.reference,
                    isasinging: true,
                    assingingon: getCurrentTimestamp,
                    riderDay: _model.createdDay?.reference,
                  ));

                  await _model.riderFound!.firstOrNull!.reference
                      .update(createUsersRecordData(
                    assigning: true,
                  ));
                }
              }
            }
          }
        }),
        Future(() async {
          while (!_model.finish) {
            await action_blocks.unassgn6(context);
          }
        }),
        Future(() async {
          while (!_model.finish) {
            _model.orderNot = await queryOrdersRecordOnce(
              queryBuilder: (ordersRecord) => ordersRecord
                  .where(
                    'accepted',
                    isNotEqualTo: true,
                  )
                  .where(
                    'status',
                    isEqualTo: 'In progress',
                  ),
              singleRecord: true,
            ).then((s) => s.firstOrNull);
            if ((_model.orderNot?.reference != null) &&
                (functions.minutes(_model.orderNot!.creaatedAt!, 5) == true)) {
              await Future.wait([
                Future(() async {
                  if (_model.orderNot?.paid == true) {
                    _model.user = await queryUsersRecordOnce(
                      queryBuilder: (usersRecord) => usersRecord.where(
                        'uid',
                        isEqualTo: _model.orderNot?.userRef?.id,
                      ),
                      singleRecord: true,
                    ).then((s) => s.firstOrNull);

                    await _model.orderNot!.userRef!.update({
                      ...mapToFirestore(
                        {
                          'Balance':
                              FieldValue.increment(_model.orderNot!.amount),
                        },
                      ),
                    });

                    await _model.orderNot!.reference
                        .update(createOrdersRecordData(
                      status: 'Failed',
                      failedreason: 'Did not respond to order',
                    ));
                  } else {
                    await _model.orderNot!.reference
                        .update(createOrdersRecordData(
                      status: 'Failed',
                      failedreason: 'Did not respond to order',
                    ));
                  }

                  triggerPushNotification(
                    notificationTitle: 'Order Failed 😢😢',
                    notificationText:
                        '${_model.orderNot?.vendorName}  Is currently not available to accept your order.. If already paid your payment will be credited into your wallet.',
                    userRefs: [_model.orderNot!.userRef!],
                    initialPageName: 'orders',
                    parameterData: {},
                  );
                }),
                Future(() async {
                  await _model.orderNot!.restaurantRef!
                      .update(createUsersRecordData(
                    acceptingOrders: false,
                  ));
                }),
              ]);
              return;
            } else {
              return;
            }
          }
        }),
        Future(() async {
          await Future.delayed(const Duration(milliseconds: 5000));
          while (!_model.finish) {
            _model.orderListFound22 = await queryOrdersRecordOnce(
              queryBuilder: (ordersRecord) => ordersRecord
                  .where(
                    'riderAssinged',
                    isEqualTo: false,
                  )
                  .where(
                    'delivered',
                    isEqualTo: false,
                  )
                  .where(
                    'isasinging',
                    isEqualTo: false,
                  )
                  .where(
                    'pickingUp',
                    isNotEqualTo: true,
                  )
                  .where(
                    'Paid',
                    isEqualTo: true,
                  )
                  .where(
                    'status',
                    isEqualTo: 'In progress',
                  ),
            );
            if (_model.orderListFound22!.length >= 1) {
              _model.riderFound2 = await queryUsersRecordOnce(
                queryBuilder: (usersRecord) => usersRecord
                    .where(
                      'online',
                      isEqualTo: true,
                    )
                    .where(
                      'isrider',
                      isEqualTo: true,
                    )
                    .where(
                      'inActiveOrder',
                      isEqualTo: false,
                    )
                    .where(
                      'ReadyToWork',
                      isEqualTo: true,
                    )
                    .where(
                      'assigning',
                      isEqualTo: false,
                    )
                    .where(
                      'country',
                      isEqualTo: _model.orderListFound22?.firstOrNull?.country,
                    )
                    .orderBy('location', descending: true),
              );
              if (functions
                  .nearByrider(
                      _model.riderFound2!
                          .where((e) =>
                              (e.online == true) &&
                              (e.isrider == true) &&
                              (e.inActiveOrder == false) &&
                              (e.readyToWork == true) &&
                              (e.assigning == false) &&
                              (e.outStandingBalance >= 199.0))
                          .toList()
                          .toList(),
                      _model.orderListFound22!
                          .where((e) => !e.riderAssinged)
                          .toList()
                          .firstOrNull!
                          .restaurantLocation!,
                      10.0)
                  .isNotEmpty) {
                _model.day2 = await queryDayMonitorRecordOnce(
                  queryBuilder: (dayMonitorRecord) => dayMonitorRecord
                      .where(
                        'date',
                        isEqualTo: functions.currentDate(getCurrentTimestamp),
                      )
                      .where(
                        'riderRef',
                        isEqualTo: functions
                            .nearByrider(
                                _model.riderFound2!
                                    .where((e) =>
                                        (e.online == true) &&
                                        (e.isrider == true) &&
                                        (e.inActiveOrder == false) &&
                                        (e.readyToWork == true) &&
                                        (e.assigning == false) &&
                                        (e.outStandingBalance >= 199.0))
                                    .toList()
                                    .toList(),
                                _model.orderListFound22!
                                    .where((e) => !e.riderAssinged)
                                    .toList()
                                    .firstOrNull!
                                    .restaurantLocation!,
                                10.0)
                            .firstOrNull
                            ?.reference,
                      ),
                  singleRecord: true,
                ).then((s) => s.firstOrNull);
                if (_model.day2?.reference != null) {
                  await _model.orderListFound22!
                      .where((e) => !e.riderAssinged)
                      .toList()
                      .firstOrNull!
                      .reference
                      .update(createOrdersRecordData(
                        deliveryRider: functions
                            .nearByrider(
                                _model.riderFound2!
                                    .where((e) =>
                                        (e.online == true) &&
                                        (e.isrider == true) &&
                                        (e.inActiveOrder == false) &&
                                        (e.readyToWork == true) &&
                                        (e.assigning == false) &&
                                        (e.outStandingBalance >= 199.0))
                                    .toList()
                                    .toList(),
                                _model.orderListFound22!
                                    .where((e) => !e.riderAssinged)
                                    .toList()
                                    .firstOrNull!
                                    .restaurantLocation!,
                                10.0)
                            .firstOrNull
                            ?.reference,
                        isasinging: true,
                        assingingon: getCurrentTimestamp,
                        riderDay: _model.day2?.reference,
                      ));

                  await functions
                      .nearByrider(
                          _model.riderFound2!
                              .where((e) =>
                                  (e.online == true) &&
                                  (e.isrider == true) &&
                                  (e.inActiveOrder == false) &&
                                  (e.readyToWork == true) &&
                                  (e.assigning == false) &&
                                  (e.outStandingBalance >= 199.0))
                              .toList()
                              .toList(),
                          _model.orderListFound22!
                              .where((e) => !e.riderAssinged)
                              .toList()
                              .firstOrNull!
                              .restaurantLocation!,
                          10.0)
                      .firstOrNull!
                      .reference
                      .update(createUsersRecordData(
                        assigning: true,
                      ));
                } else {
                  var dayMonitorRecordReference2 =
                      DayMonitorRecord.collection.doc();
                  await dayMonitorRecordReference2
                      .set(createDayMonitorRecordData(
                    date: functions.currentDate(getCurrentTimestamp),
                    riderRef: functions
                        .nearByrider(
                            _model.riderFound2!
                                .where((e) =>
                                    (e.online == true) &&
                                    (e.isrider == true) &&
                                    (e.inActiveOrder == false) &&
                                    (e.readyToWork == true) &&
                                    (e.assigning == false) &&
                                    (e.outStandingBalance >= 199.0))
                                .toList()
                                .toList(),
                            _model.orderListFound22!
                                .where((e) => !e.riderAssinged)
                                .toList()
                                .firstOrNull!
                                .restaurantLocation!,
                            10.0)
                        .firstOrNull
                        ?.reference,
                  ));
                  _model.createdDay2 = DayMonitorRecord.getDocumentFromData(
                      createDayMonitorRecordData(
                        date: functions.currentDate(getCurrentTimestamp),
                        riderRef: functions
                            .nearByrider(
                                _model.riderFound2!
                                    .where((e) =>
                                        (e.online == true) &&
                                        (e.isrider == true) &&
                                        (e.inActiveOrder == false) &&
                                        (e.readyToWork == true) &&
                                        (e.assigning == false) &&
                                        (e.outStandingBalance >= 199.0))
                                    .toList()
                                    .toList(),
                                _model.orderListFound22!
                                    .where((e) => !e.riderAssinged)
                                    .toList()
                                    .firstOrNull!
                                    .restaurantLocation!,
                                10.0)
                            .firstOrNull
                            ?.reference,
                      ),
                      dayMonitorRecordReference2);

                  await _model.orderListFound22!
                      .where((e) => !e.riderAssinged)
                      .toList()
                      .firstOrNull!
                      .reference
                      .update(createOrdersRecordData(
                        deliveryRider: functions
                            .nearByrider(
                                _model.riderFound2!
                                    .where((e) =>
                                        (e.online == true) &&
                                        (e.isrider == true) &&
                                        (e.inActiveOrder == false) &&
                                        (e.readyToWork == true) &&
                                        (e.assigning == false) &&
                                        (e.outStandingBalance >= 199.0))
                                    .toList()
                                    .toList(),
                                _model.orderListFound22!
                                    .where((e) => !e.riderAssinged)
                                    .toList()
                                    .firstOrNull!
                                    .restaurantLocation!,
                                10.0)
                            .firstOrNull
                            ?.reference,
                        isasinging: true,
                        assingingon: getCurrentTimestamp,
                        riderDay: _model.createdDay2?.reference,
                      ));

                  await functions
                      .nearByrider(
                          _model.riderFound2!
                              .where((e) =>
                                  (e.online == true) &&
                                  (e.isrider == true) &&
                                  (e.inActiveOrder == false) &&
                                  (e.readyToWork == true) &&
                                  (e.assigning == false) &&
                                  (e.outStandingBalance >= 199.0))
                              .toList()
                              .toList(),
                          _model.orderListFound22!
                              .where((e) => !e.riderAssinged)
                              .toList()
                              .firstOrNull!
                              .restaurantLocation!,
                          10.0)
                      .firstOrNull!
                      .reference
                      .update(createUsersRecordData(
                        assigning: true,
                      ));
                }
              }
            }
          }
        }),
      ]);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        body: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0.0, 45.0, 0.0, 0.0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: FFButtonWidget(
                  onPressed: () async {
                    _model.unsignOrdery = await queryOrdersRecordOnce(
                      queryBuilder: (ordersRecord) => ordersRecord
                          .where(
                            'riderAssinged',
                            isEqualTo: false,
                          )
                          .where(
                            'status',
                            isEqualTo: 'In progress',
                          )
                          .where(
                            'pickingUp',
                            isEqualTo: false,
                          )
                          .where(
                            'delivered',
                            isEqualTo: false,
                          )
                          .where(
                            'isasinging',
                            isEqualTo: false,
                          ),
                      singleRecord: true,
                    ).then((s) => s.firstOrNull);

                    safeSetState(() {});
                  },
                  text: FFLocalizations.of(context).getText(
                    '4wmv7az3' /* Button */,
                  ),
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily:
                              FlutterFlowTheme.of(context).titleSmallFamily,
                          color: Colors.white,
                          letterSpacing: 0.0,
                          useGoogleFonts:
                              !FlutterFlowTheme.of(context).titleSmallIsCustom,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
